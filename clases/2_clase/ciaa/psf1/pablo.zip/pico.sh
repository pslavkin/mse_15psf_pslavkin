picocom  /dev/ttyUSB1 -b 460800 --log log.bin #> /dev/null
